# Where My Budget At Budget Tracker #
The main goal of this budget tracker is to help people visually see and track their budget progress as well as help track their personal goals such as paying off a debt, saving, creating an emergency fund, etc.

## Description ##
This program takes in numerical information from the user and transforms it so that it can be seen on a visual tracker (pie chart). In the future, we hope to implement a way to notify users when the program detects they may be lacking in their progress towards goals as well as eventually linking our program to the users bank account so that they no longer have to manually input their financial information.

## Installing the Project and Needed Files ##
1. Clone or download the project
2. Ensure the src folder contains java files only and an out folder
3. Ensure the out folder contains fxml files
4. Download Jackson jar files (so that the database works):
   
     -   [jackson-annotations-3.0-rc2](https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-annotations/3.0-rc2)
     -   [jackson-core-2.19.0-rc2](https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-core/2.19.0-rc2)
     -   [jackson-databind-2.19.0-rc2](https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-databind)
  
5. After downloading the files, put them all in one folder name "jackson"
6. Download Javafx version 23.0.2, type SDK, [click here](https://gluonhq.com/products/javafx/)

## Compiling and Running the Project ##
To compile and run you will need to know the location of the javafx lib, your jackson folder (as explained above), and the files from the project. With the command below, insert your file paths in the appropriate spots.

**Compile Command:** 

javac --endable-preview --release 23 --module-path "your javafx lib path;Your jackson folder path" --add-modules javafx.controls,javafx.fxml,com.fasterxml.jackson.databind -d out "your project path to the src folder/*.java"

In the build.xml file (Things you'll need to change):
   - Change the location for your javafx and jackson files respectively (navigate in your directory for the javafx and jackson files, type pwd for each, copy and paste into location for each          respectively in the build.xml file.
   - You will get the error "FXML file not found: WelcomeDocument.fxml", just copy this file into the out folder.
   - Make sure the releases or versions of javafx and jackson match the ones on your computer. I have javafx version 21.0.6, but you may have a different version.

**Example Compile Command with Paths:** 

javac --enable-preview --release 23 --module-path "your javafx lib path;Your jackson folder files" --add-modules javafx.controls,javafx.fxml,com.fasterxml.jackson.databind -d out "C:/Users/major/Documents/cs371/cs371-sp2025-teamproject-where-my-budget-at/src/*.java"

    <property name = "javafx" location = "/Users/elizabethtorres/Documents/javafx-sdk-21.0.6/lib"/>
    <property name = "jackson" location = "/Users/elizabethtorres/Documents/jackson" />

**Run Command:**

java --enable-preview --module-path "your javafx lib file path;Your jackson folder path" --add-modules javafx.controls,javafx.fxml,com.fasterxml.jackson.databind -cp out Main

In the build.xml file (Things you'll need to change):
   - Change the location for your javafx and jackson files respectively (navigate in your directory for the javafx and jackson files, type pwd for each, copy and paste into location for each          respectively in the build.xml file.
   - You will get the error "FXML file not found: WelcomeDocument.fxml", just copy this file into the out folder.
   - - Make sure the releases or versions of javafx and jackson match the ones on your computer. I have javafx version 21.0.6, but you may have a different version.

**Example Run Command with Paths:**

java --enable-preview --module-path "C:/Users/major/Downloads/openjfx-23.0.2_windows-x64_bin-sdk/javafx-sdk-23.0.2/lib;C:/Users/major/Downloads/jackson" --add-modules javafx.controls,javafx.fxml,com.fasterxml.jackson.databind -cp out Main

    <property name = "javafx" location = "/Users/elizabethtorres/Documents/javafx-sdk-21.0.6/lib"/>
    <property name = "jackson" location = "/Users/elizabethtorres/Documents/jackson" />

   
