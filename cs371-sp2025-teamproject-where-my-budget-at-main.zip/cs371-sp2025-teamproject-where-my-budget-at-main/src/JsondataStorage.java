// Author: Jordan Henderson
// Hopefully will store the data for the database


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;


// Author: Jordan Henderson
// Stores the user information for the database

public class JsondataStorage {


    private static final String DATA_FILE = "budget_data.json";
    private static final ObjectMapper mapper = new ObjectMapper()
        .enable(SerializationFeature.INDENT_OUTPUT)
        .disable(com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);


    // saves the users (usernames) to a file
    public static void saveUsers(List<User> users) throws IOException {
        File file = new File(DATA_FILE);
        if (!file.exists()) {
            file.createNewFile();
        }
        mapper.writeValue(file, users);
    } // end saveUsers


    // loads in the users
    public static List<User> loadUsers() throws IOException {
        File file = new File(DATA_FILE);
        System.out.println("Resolved file path: " + file.getAbsolutePath());
        if (!file.exists()) {
            System.out.println("File does not exist. Attempting to create it...");
            System.out.println("File not found: " + file.getAbsolutePath());
            return new ArrayList<>();
        }
        try {
            return mapper.readValue(file, mapper.getTypeFactory().constructCollectionType(List.class, User.class));
        } catch (IOException e) {
            System.err.println("Error reading JSON file: " + e.getMessage());
            return new ArrayList<>();
        }
    } // end of loadUsers


    // finds a user by their username
    public static User findUserByUsername(String username) throws IOException {
        List<User> users = loadUsers();
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            } // end of if statement
        } // end of for loop
        return null; // returns null if the user is not found
    } // end of findUserByUsername


    // updates a user in the list of users or adds a new one
    public static void saveUser(User updatedUser) throws IOException {
        List<User> users = loadUsers();
        users.removeIf(user -> user.getUsername().equals(updatedUser.getUsername()));
        users.add(updatedUser);
        saveUsers(users);
    } // end saveUser


    public static User findUser(String username) throws IOException {
        List<User> users = loadUsers();
        System.out.println("Loaded users: " + users.size());
        for (User user : users) {
            System.out.println("Checking user: " + user.getUsername());
            if (user.getUsername().equals(username)) {
                System.out.println("User found: " + username);
                return user;
            }
        }
        System.out.println("User not found: " + username);
        return null;
    }
} // end of class

