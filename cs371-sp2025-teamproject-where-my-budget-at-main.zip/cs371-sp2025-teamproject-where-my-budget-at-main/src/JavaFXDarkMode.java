/*import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Control;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.Node;

// Author: Elizabeth Torres 
// Jordan Henderson helped with errors
public class JavaFXDarkMode extends Application {
    // Author: Elizabeth Torres
    private DarkModeManager darkModeManager = DarkModeManager.getInstance();
    private VBox root;
    private Button button;
    private CheckBox toggle;
    private boolean darkMode;

    // Author: Elizabeth Torres
    @Override
    public void start(Stage primaryStage) {
        button = new Button("Click me to change the light/dark theme");
        toggle = new CheckBox("Dark Mode");
        toggle.setSelected(darkModeManager.isDarkModeEnabled());

        root = new VBox(10, toggle, button);
        Scene scene = new Scene(root, 300, 200);

        applyLightMode();

        toggle.selectedProperty().addListener((obs, oldVal, newVal) -> {
            darkMode = newVal;
            if (darkMode) {
                applyDarkMode();
            } else {
                applyLightMode();
            }
        });

        if (scene.getRoot() instanceof Region) {
            applyDarkStyles((Region) scene.getRoot());
        }

        primaryStage.setTitle("JavaFX Dark Mode");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    // Author: Elizabeth Torres
    private void applyDarkMode() {
        root.setStyle("-fx-background-color: #4CAF50;");
        button.setStyle("-fx-background-color: #505050; -fx-text-fill: #e0e0e0;");
        toggle.setStyle("-fx-text-fill: #e0e0e0;");
    }

    // Author: Elizabeth Torres
    private void applyLightMode() {
        root.setStyle("-fx-background-color: #4CAF50;");
        button.setStyle("-fx-background-color: #e0e0e0; -fx-text-fill: #333333;");
        toggle.setStyle("-fx-text-fill: #333333;");
    }

    // Author: Elizabeth Torres
    private void applyDarkStyles(Region parent) {
        if (parent instanceof javafx.scene.Parent) {
            for (Node node : ((javafx.scene.Parent) parent).getChildrenUnmodifiable()) {
                System.out.println("Processing node: " + node.getClass().getName());
                if (node instanceof Control) {
                    Control control = (Control) node;
                    control.setStyle("-fx-background-color: #505050; -fx-text-fill: #e0e0e0;");
                } else if (node instanceof Region) {
                    applyDarkStyles((Region) node); // Recursive call for nested regions
                }
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}*/