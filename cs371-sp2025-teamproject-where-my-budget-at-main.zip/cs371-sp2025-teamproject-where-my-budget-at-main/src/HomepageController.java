import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.scene.layout.AnchorPane;
import javax.print.attribute.standard.MediaSize;
import javafx.scene.control.Button;

// Authors: Leon Nguyen and Jordan Henderson
public class HomepageController {

    @FXML private AnchorPane homepage;
    @FXML private AnchorPane housingpage;
    @FXML private AnchorPane foodpage;
    @FXML private AnchorPane otherpage;
    @FXML private AnchorPane savingspage;

    @FXML private MenuButton menuButton;
    @FXML private PieChart pieChart1;
    @FXML private TextField categoryInput;
    @FXML private TextField valueInput;

    @FXML private Button housingBtn_pieChart;
    @FXML private Button foodBtn_pieChart;
    @FXML private Button otherBtn_pieChart;
    @FXML private Button savingsBtn_pieChart;

    @FXML private Button housingBtn_foodPieChart;
    @FXML private Button housingBtn_otherPieChart;
    @FXML private Button housingBtn_savingsPieChart;

    @FXML private Button foodBtn_housingPieChart;
    @FXML private Button foodBtn_otherPieChart;
    @FXML private Button foodBtn_savingsPieChart;

    @FXML private Button otherBtn_housingPieChart;
    @FXML private Button otherBtn_foodPieChart;
    @FXML private Button otherBtn_savingsPieChart;

    @FXML private Button savingsBtn_housingPieChart;
    @FXML private Button savingsBtn_foodPieChart;
    @FXML private Button savingsBtn_otherPieChart;

    @FXML private Button homeBtn_housingPieChart;
    @FXML private Button homeBtn_foodPieChart;
    @FXML private Button homeBtn_otherPieChart;
    @FXML private Button homeBtn_savingsPieChart;

    @FXML private PieChart housing_pieChart;
    @FXML private TextField housingSubcategoryInput;
    @FXML private TextField housingAmountInput;

    @FXML private PieChart foodPieChart;
    @FXML private TextField foodSubcategoryInput;
    @FXML private TextField foodAmountInput;

    @FXML private PieChart otherPieChart;
    @FXML private TextField otherSubcategoryInput;
    @FXML private TextField otherAmountInput;

    // Author: Jordan Henderson
    @FXML
    public void initialize() {
        setupSampleData();
        setupButtonActions();
    }

    // Author: Leon Nguyen
    @FXML
    private void handleProfileClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("profile.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) menuButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load profile: " + e.getMessage());
        } // end of catch
    } // end of handleProfileClick

    // Author: Leon Nguyen
    @FXML
    private void handleSettingsClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) menuButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load settings: " + e.getMessage());
        }
    }

    // Author: Leon Nguyen
    @FXML
    private void handleLogoutClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("signout.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) menuButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load signout: " + e.getMessage());
        }
    }

    // Author: Leon Nguyen
    @FXML
    private void handleAddData() {
        try {
            String category = categoryInput.getText().trim();
            double value = Double.parseDouble(valueInput.getText());
            
            if (category.isEmpty()) {
                showAlert("Hold on!", "Category cannot be empty");
                return;
            }
            
            if (!isValidCategory(category)) {
                showAlert("Oh no!", "Please choose from Housing, Food, Others, or Savings to add.");
                return;
            }
            
            updatePieChartData(pieChart1, category, value);
    
            // Clear inputs
            categoryInput.clear();
            valueInput.clear();
            
        } catch (NumberFormatException e) {
            showAlert("Wait a minute!", "Please enter a valid number for value");
        }
    }
    
    private boolean isValidCategory(String category) {
        String[] allowedCategories = {"Housing", "Food", "Other", "Savings"};
        for (String allowedCategory : allowedCategories) {
            if (category.equalsIgnoreCase(allowedCategory)) {
                return true;
            }
        }
        return false;
    }

    // Author: Jordan Henderson and Leon Nguyen
    private void updatePieChartData(PieChart chart, String category, double value) {
        boolean found = false;
        for (PieChart.Data data : chart.getData()) {
            if (data.getName().equals(category)) {
                data.setPieValue(data.getPieValue() + value);
                found = true;
                break;
            }
        }
        if (!found) {
            chart.getData().add(new PieChart.Data(category, value));
        }
    }

    // Author: Jordan Henderson
    private void setupSampleData() {

        pieChart1.getData().addAll(
            new PieChart.Data("Housing", 0),
            new PieChart.Data("Food", 0),
            new PieChart.Data("Other", 0),
            new PieChart.Data("Savings", 0)
        );

        housing_pieChart.getData().addAll(
            new PieChart.Data("Rent/Mortgage", 0),
            new PieChart.Data("Electricity", 0),
            new PieChart.Data("Water", 0),
            new PieChart.Data("Internet", 0),
            new PieChart.Data("Natural Gas", 0),
            new PieChart.Data("Trash", 0),
            new PieChart.Data("Insurance", 0),
            new PieChart.Data("Maintenance", 0)
        );
        

        foodPieChart.getData().addAll(
            new PieChart.Data("Groceries", 0),
            new PieChart.Data("Restaurants", 0)
        );

        otherPieChart.getData().addAll(
            new PieChart.Data("Entertainment", 0),
            new PieChart.Data("Transportation", 0),
            new PieChart.Data("Medical", 0),
            new PieChart.Data("Pets", 0),
            new PieChart.Data("Clothing", 0), 
            new PieChart.Data("Miscellaneous", 0)
        );
    }

    // Author: Jordan Henderson
    private void setupButtonActions() {
        housingBtn_pieChart.setOnAction(e->showPage(housingpage));
        foodBtn_pieChart.setOnAction(e->showPage(foodpage));
        otherBtn_pieChart.setOnAction(e->showPage(otherpage));
        savingsBtn_pieChart.setOnAction(e->showPage(savingspage));

        housingBtn_foodPieChart.setOnAction(e->showPage(housingpage));
        housingBtn_otherPieChart.setOnAction(e->showPage(housingpage));
        housingBtn_savingsPieChart.setOnAction(e->showPage(housingpage));

        foodBtn_housingPieChart.setOnAction(e->showPage(foodpage));
        foodBtn_otherPieChart.setOnAction(e->showPage(foodpage));
        foodBtn_savingsPieChart.setOnAction(e->showPage(foodpage));

        otherBtn_housingPieChart.setOnAction(e->showPage(otherpage));
        otherBtn_foodPieChart.setOnAction(e->showPage(otherpage));
        otherBtn_savingsPieChart.setOnAction(e->showPage(otherpage));

        savingsBtn_housingPieChart.setOnAction(e->showPage(savingspage));
        savingsBtn_foodPieChart.setOnAction(e->showPage(savingspage));
        savingsBtn_otherPieChart.setOnAction(e->showPage(savingspage));

        homeBtn_housingPieChart.setOnAction(e->showPage(homepage));
        homeBtn_foodPieChart.setOnAction(e->showPage(homepage));
        homeBtn_otherPieChart.setOnAction(e->showPage(homepage));
        homeBtn_savingsPieChart.setOnAction(e->showPage(homepage));
    } // end of setupButtonActions

    // Author: Jordan Henderson
    private void showPage(AnchorPane page) {
        homepage.setVisible(false);
        housingpage.setVisible(false);
        foodpage.setVisible(false);
        otherpage.setVisible(false);
        savingspage.setVisible(false);

        page.setVisible(true);
    } // end of showPage

    // Author: Leon Nguyen
    private void loadScene(String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) menuButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            showAlert("Navigation Error", "Failed to load " + fxmlFile + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAddTransaction() {
        addDataToChart(pieChart1, categoryInput, valueInput);
    }

    @FXML
    private void handleAddHousingExpense() {
        addDataToChart(housing_pieChart, housingSubcategoryInput, housingAmountInput);
    }

    @FXML
    private void handleAddFoodExpense() {
        addDataToChart(foodPieChart, foodSubcategoryInput, foodAmountInput);
    }

    @FXML
    private void handleAddOtherExpense() {
        addDataToChart(otherPieChart, otherSubcategoryInput, otherAmountInput);
    }

    private void addDataToChart(PieChart chart, TextField categoryField, TextField amountField) {
        try {
            String category = categoryField.getText().trim();
            double amount = Double.parseDouble(amountField.getText().trim());
            
            if (category.isEmpty()) {
                showAlert("Input Error", "Category cannot be empty");
                return;
            }

            boolean found = false;
            for (PieChart.Data data : chart.getData()) {
                if (data.getName().equals(category)) {
                    data.setPieValue(data.getPieValue() + amount);
                    found = true;
                    break;
                }
            }
            
            if (!found) {
                chart.getData().add(new PieChart.Data(category, amount));
            }
            
            categoryField.clear();
            amountField.clear();
            
            if (chart != pieChart1) {
                updateMainChartSummary();
            }
            
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Please enter a valid number for amount");
        }
    }

    private void updateMainChartSummary() {
        double housingTotal = housing_pieChart.getData().stream()
            .mapToDouble(PieChart.Data::getPieValue)
            .sum();
            
        double foodTotal = foodPieChart.getData().stream()
            .mapToDouble(PieChart.Data::getPieValue)
            .sum();
            
        double otherTotal = otherPieChart.getData().stream()
            .mapToDouble(PieChart.Data::getPieValue)
            .sum();
        

        for (PieChart.Data data : pieChart1.getData()) {
            switch (data.getName()) {
                case "Housing":
                    data.setPieValue(housingTotal);
                    break;
                case "Food":
                    data.setPieValue(foodTotal);
                    break;
                case "Other":
                    data.setPieValue(otherTotal);
                    break;
   }
        }
    }

    // Author: Leon Nguyen
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Author: Leon Nguyen
    public void setCurrentUser(User user) {
        System.out.println("Current user set to: " + user.getUsername());
    }
    //author: Angel Martinez
        @FXML
    private void handleSavingsGoalsClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/UserSavings.fxml"));
            Parent root = loader.load();
    
    
            Stage stage = (Stage) menuButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Savings Goals");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load Savings Goals page.");
        }
    }
    //Angel Martinez
    @FXML
    private void handleResourcesClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Resources.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) menuButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Resources");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load Resources page.");
        }
    }
}