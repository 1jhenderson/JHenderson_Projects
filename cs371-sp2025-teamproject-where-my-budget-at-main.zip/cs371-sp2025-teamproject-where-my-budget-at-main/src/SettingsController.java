import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;

public class SettingsController {

    // FXML injected fields
    @FXML
    private CheckBox notificationsCheckBox;
    
    @FXML
    private CheckBox darkModeCheckBox;
    
    @FXML
    private CheckBox autoLoginCheckBox;
    
    @FXML
    private Button clearAllDataButton;
    
    @FXML
    private Button saveChangesButton;

    @FXML
    private Button backButton;

    // Initialize method
    @FXML
    private void initialize() {
        // Load current settings (you would typically load from preferences)
        loadCurrentSettings();
        backButton.setOnAction(event -> handleBackButton());

        
        // Set up event handlers
        saveChangesButton.setOnAction(event -> handleSaveChanges());
    }
    
    // Load current settings (mock implementation)
    private void loadCurrentSettings() {
        // In a real app, you would load these from preferences
        notificationsCheckBox.setSelected(true);
        darkModeCheckBox.setSelected(false);
        autoLoginCheckBox.setSelected(true);
    }


    private void handleBackButton() {
    try {
        Parent root = FXMLLoader.load(getClass().getResource("homepage.fxml"));
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.setScene(new Scene(root));
    } catch (IOException e) {
        e.printStackTrace();
        // Handle error
    }
}
    
    // Handle save changes button
    private void handleSaveChanges() {
        // Get current settings
        boolean notificationsEnabled = notificationsCheckBox.isSelected();
        boolean darkModeEnabled = darkModeCheckBox.isSelected();
        boolean autoLoginEnabled = autoLoginCheckBox.isSelected();
        
        // Save settings (in a real app, you would save to preferences)
        System.out.println("Saving settings:");
        System.out.println("Notifications: " + notificationsEnabled);
        System.out.println("Dark Mode: " + darkModeEnabled);
        System.out.println("Auto Login: " + autoLoginEnabled);
        
        // Show confirmation
        showAlert(AlertType.INFORMATION, "Settings Saved", "Your settings have been saved successfully.");
    }
    
    // Handle clear all data button
    @FXML
    private void handleClearAllData() {
        // Show confirmation dialog
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirm Clear Data");
        alert.setHeaderText("Clear All Data");
        alert.setContentText("Are you sure you want to delete all application data? This cannot be undone.");

    }
    
    // Helper method to show alerts
    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}