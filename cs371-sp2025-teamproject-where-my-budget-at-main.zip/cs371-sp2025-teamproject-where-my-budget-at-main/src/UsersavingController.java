// //Author : Angel Martinez
// // This class is used to manage the user's savings goals in the application. It allows users to add, remove, and view their savings goals.
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.scene.control.Button;


public class UsersavingController {


   @FXML
   private Label welcomeLabel;


   @FXML
   private Label incomeLabel;


   @FXML
   private TableView<UserSavings> savingsTable;


   @FXML
   private TableColumn<UserSavings, String> goalColumn;


   @FXML
   private TableColumn<UserSavings, Double> targetAmountColumn;


   @FXML
   private TableColumn<UserSavings, Double> currentAmountColumn;


   @FXML
   private Button addButton;


   @FXML
   private Button removeButton;


   @FXML
   private Button backToHomeButton;


   private ObservableList<UserSavings> savingsList;


   private User currentUser;


   @FXML
   private AnchorPane savingsView;


   @FXML
   private StackPane inputView;


   // Multi-step input fields
   @FXML
   private VBox step1;


   @FXML
   private VBox step2;


   @FXML
   private VBox step3;


   @FXML
   private TextField goalNameField;


   @FXML
   private TextField goalAmountField;


   @FXML
   private TextField goalTimeField;


   private String goalName;
   private double goalAmount;
   private int goalTime;


   public void setCurrentUser(User user) {
       this.currentUser = user;
       welcomeLabel.setText("Welcome, " + user.getUsername() + "!");
       incomeLabel.setText(" Disposable Income: $" + String.format("%.2f", user.getIncomeInfo().getIncomeAmount()));
   }


   @FXML
   public void initialize() {
       goalColumn.setCellValueFactory(new PropertyValueFactory<>("savingsGoal"));
       targetAmountColumn.setCellValueFactory(new PropertyValueFactory<>("targetAmount"));
       currentAmountColumn.setCellValueFactory(new PropertyValueFactory<>("currentAmount"));


       savingsList = FXCollections.observableArrayList();
       savingsTable.setItems(savingsList);


       addButton.setOnAction(event -> openSavingsInput());
       removeButton.setOnAction(event -> removeSelectedSavingsGoal());
       backToHomeButton.setOnAction(event -> goToHomepage());
   }


   @FXML
   private void openSavingsInput() {
       // Show the input form and hide the savings table
       savingsView.setVisible(false);
       inputView.setVisible(true);


       // Reset the form
       step1.setVisible(true);
       step2.setVisible(false);
       step3.setVisible(false);


       goalNameField.clear();
       goalAmountField.clear();
       goalTimeField.clear();
   }


   @FXML
   private void goToStep2() {
       if (goalNameField.getText().isEmpty()) {
           showAlert("Input Error", "Please enter a goal name.");
           return;
       }
       step1.setVisible(false);
       step2.setVisible(true);
   }


   @FXML
   private void goToStep3() {
       if (goalAmountField.getText().isEmpty()) {
           showAlert("Input Error", "Please enter a goal amount.");
           return;
       }
       step2.setVisible(false);
       step3.setVisible(true);
   }


   @FXML
   private void submitGoal() {
       if (goalTimeField.getText().isEmpty()) {
           showAlert("Input Error", "Please enter a timeline.");
           return;
       }


       // Add the new goal to the savings table (logic to be implemented)
       System.out.println("Goal submitted: " + goalNameField.getText() + ", " + goalAmountField.getText() + ", " + goalTimeField.getText());


       // Return to the savings table view
       savingsView.setVisible(true);
       inputView.setVisible(false);
   }


   @FXML
   private void cancelInput() {
       // Return to the savings table view without saving
       savingsView.setVisible(true);
       inputView.setVisible(false);
   }


   private void removeSelectedSavingsGoal() {
       UserSavings selectedGoal = savingsTable.getSelectionModel().getSelectedItem();
       if (selectedGoal != null) {
           savingsList.remove(selectedGoal);
       }
   }


   private void goToHomepage() {
       try {
           Parent root = FXMLLoader.load(getClass().getResource("homepage.fxml"));
           Scene scene = new Scene(root);
           Stage stage = (Stage) savingsView.getScene().getWindow();
           stage.setScene(scene);
           stage.show();
       } catch (IOException e) {
           e.printStackTrace();
       }
   }


   private void closeWindow() {
       Stage stage = (Stage) step1.getScene().getWindow();
       stage.close();
   }


   private void showAlert(String title, String message) {
       Alert alert = new Alert(Alert.AlertType.ERROR);
       alert.setTitle(title);
       alert.setHeaderText(null);
       alert.setContentText(message);
       alert.showAndWait();
   }
}
