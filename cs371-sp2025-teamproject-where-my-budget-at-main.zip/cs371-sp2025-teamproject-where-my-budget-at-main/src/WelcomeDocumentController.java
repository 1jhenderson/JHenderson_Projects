import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.ComboBox;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.collections.ObservableList;
import java.util.List;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


// Author: Jordan Henderson. All functions were used.
// The hardcoded login is only used in case of emergency
// and was used before the database was working


public class WelcomeDocumentController implements Initializable {
    @FXML
    private Button changePass_backBtn;
    @FXML
    private PasswordField changePass_cPassword;
    @FXML
    private Button changePass_continueBtn;
    @FXML
    private AnchorPane changePass_form;
    @FXML
    private PasswordField changePass_password;
    @FXML
    private TextField forgot_answer;
    @FXML
    private Button forgot_backBtn;
    @FXML
    private Button forgot_continueBtn;
    @FXML
    private AnchorPane forgot_form;
    @FXML
    private ComboBox<String> forgot_selectQuestion;
    @FXML
    private TextField forgot_username;
    @FXML
    private Button login_btn;
    @FXML
    private Button login_createAccount;
    @FXML
    private Hyperlink login_forgotPassword;
    @FXML
    private AnchorPane login_form;
    @FXML
    private PasswordField login_password;
    @FXML
    private CheckBox login_selectShowPassword;
    @FXML
    private TextField login_showPassword;
    @FXML
    private TextField login_username;
    @FXML
    private AnchorPane main_form;
    @FXML
    private TextField signup_answer;
    @FXML
    private Button signup_btn;
    @FXML
    private PasswordField signup_cPassword;
    @FXML
    private AnchorPane signup_form;
    @FXML
    private Button signup_loginAccount;
    @FXML
    private PasswordField signup_password;
    @FXML
    private ComboBox<String> signup_selectQuestion;
    @FXML
    private TextField signup_username;




    private String[] questionList = {
        "What was the name of your first pet?",
        "What is the model of your first vehicle?",
        "What is your favorite color?",
        "What high school did you go to?"};

    public void login() {
        alertMessage alert = new alertMessage();
        String username = login_username.getText();
        String password = login_password.getText();


        try {
            User user = JsondataStorage.findUser(username);
            if (user != null && user.getPassword().equals(password)) {
                loadHomepage();
                alert.successMessage("Login Successful");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } // end of catch


        System.out.println("Login button clicked!");


        // hardcoded login
        if (username.equals("admin") /*&& password.equals("admin123")*/) {
            loadHomepage();
            alert.successMessage("Login Successful");
            return;
        }
    }
    private void loadHomepage() {
        try {
            URL fxmlUrl = getClass().getResource("homepage.fxml");

            if (fxmlUrl == null) {
                System.out.println("Error: homepage.fxml not found in the classpath.");
                throw new IOException("Cannot find homepage.fxml in the classpath.");
            }

            System.out.println("Classpath: " + System.getProperty("java.class.path"));
            System.out.println("Attempting to load homepage.fxml...");
            System.out.println("FXML found at: " + fxmlUrl);
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();

            Stage currentStage = (Stage) login_btn.getScene().getWindow();
            currentStage.setScene(new Scene(root));
            currentStage.setTitle("Homepage");
            currentStage.show();

        } catch (IOException e) {
            e.printStackTrace();

            alertMessage alert = new alertMessage();
            alert.errorMessage("Failed to load homepage.fxml: " + e.getMessage());
        }
    }

    public void showPassword() {
        if(login_selectShowPassword.isSelected()) {
            login_showPassword.setText(login_password.getText());
            login_showPassword.setVisible(true);
            login_password.setVisible(false);
        } else {
            login_password.setText(login_showPassword.getText());
            login_showPassword.setVisible(false);
            login_password.setVisible(true);
        }
    }


    public void forgotPassword() {
        alertMessage alert = new alertMessage();

        // Validate that all fields are filled
        if (forgot_username.getText().isEmpty()
            || forgot_selectQuestion.getValue() == null
            || forgot_answer.getText().isEmpty()) {
            alert.errorMessage("All fields must be filled");
            return;
        }

        try {
            // Fetch the user from the database
            User user = JsondataStorage.findUser(forgot_username.getText());

            // Check if the user exists and the security question/answer matches
            if (user != null &&
                user.getSecurityQuestion().equals(forgot_selectQuestion.getValue()) &&
                user.getSecurityAnswer().equals(forgot_answer.getText())) {

                // Show the change password form
                signup_form.setVisible(false);
                login_form.setVisible(false);
                forgot_form.setVisible(false);
                changePass_form.setVisible(true);

            } else {
                alert.errorMessage("Incorrect Information");
            }
        } catch (Exception e) {
            e.printStackTrace();
            alert.errorMessage("Error: Unable to validate user information");
        }
    }

    public void forgotListQuestion() {
        List<String> listQ = new ArrayList<>();
        for(String data : questionList) {
            listQ.add(data);
        }
        ObservableList<String> listData = FXCollections.observableArrayList(listQ);
        forgot_selectQuestion.setItems(listData);
    }




    public void signup() {
        alertMessage alert = new alertMessage();
        String username = signup_username.getText();
        String password = signup_password.getText();
        String userIncome = ""; // Placeholder for user income
        String firstName = ""; // Placeholder for first name
        String lastName = ""; // Placeholder for last name
        String email = ""; // Placeholder for email


        try {
            if (JsondataStorage.findUser(username) != null) {
                alert.errorMessage("Username already exists");
                return;
            } // end of if statement
            UserIncome userIncomeObj = new UserIncome("Salary", 5000.0); // just a placeholder
            User newUser = new User(username, password, userIncomeObj, firstName, lastName, email, signup_selectQuestion.getValue(), signup_answer.getText());

            JsondataStorage.saveUser(newUser);
            alert.successMessage("User created successfully");

            FXMLLoader loader = new FXMLLoader(getClass().getResource("userincome.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) signup_btn.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

            signUpClearFields();

        } catch (Exception e) {
            e.printStackTrace();
            alert.errorMessage("Error: loading users " + e.getMessage());
        } // end of catch

        if (signup_username.getText().isEmpty() ||
            signup_password.getText().isEmpty() ||
            signup_cPassword.getText().isEmpty() ||
            signup_selectQuestion.getValue() == null ||
            signup_answer.getText().isEmpty()) {
            alert.errorMessage("All fields must be filled");
            return;
        }
        if (!signup_password.getText().equals(signup_cPassword.getText())) {
            alert.errorMessage("Passwords don't match");
            return;
        }
        if (signup_password.getText().length() < 8) {
            alert.errorMessage("Password must be at least 8 characters");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/userincome.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) signup_btn.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Income Information");
            stage.show();
            signUpClearFields();
        } catch (IOException e) {
            e.printStackTrace();
            alert.errorMessage("Error loading income form: " + e.getMessage());
        }
    }




    public void signUpClearFields() {
        signup_username.setText("");
        signup_password.setText("");
        signup_cPassword.setText("");
        signup_selectQuestion.setValue(null);
        signup_answer.setText("");
    }




    public void changePassword() {
        alertMessage alert = new alertMessage();




        if(changePass_password.getText().isEmpty() || changePass_cPassword.getText().isEmpty()) {
            alert.errorMessage("All fields must be filled");
        } else if(!changePass_password.getText().equals(changePass_cPassword.getText())) {
            alert.errorMessage("Passwords do not match");
        } else if(changePass_password.getText().length() < 8) {
            alert.errorMessage("Password must be longer than 8 characters");
        } else {
            alert.successMessage("Password Changed Successfully!");
            signup_form.setVisible(false);
            login_form.setVisible(true);
            forgot_form.setVisible(false);
            changePass_form.setVisible(false);
            changePass_password.setText("");
            changePass_cPassword.setText("");
        }
    }




    public void switchForm(ActionEvent event) {
        if(event.getSource() == signup_loginAccount || event.getSource() == forgot_backBtn) {
            signup_form.setVisible(false);
            login_form.setVisible(true);
            forgot_form.setVisible(false);
            changePass_form.setVisible(false);
        } else if (event.getSource() == login_createAccount) {
            signup_form.setVisible(true);
            login_form.setVisible(false);
            forgot_form.setVisible(false);
            changePass_form.setVisible(false);
        } else if (event.getSource() == login_forgotPassword) {
            signup_form.setVisible(false);
            login_form.setVisible(false);
            forgot_form.setVisible(true);
            changePass_form.setVisible(false);
            forgotListQuestion();
        } else if (event.getSource() == changePass_backBtn){
            signup_form.setVisible(false);
            login_form.setVisible(false);
            forgot_form.setVisible(true);
            changePass_form.setVisible(false);
        }
    }




    public void questions() {
        List<String> listQ = new ArrayList<>();
        for(String data : questionList) {
            listQ.add(data);
        }
        ObservableList<String> listData = FXCollections.observableArrayList(listQ);
        signup_selectQuestion.setItems(listData);
    }




    @Override
    public void initialize(URL url, ResourceBundle rb) {
        questions();
        forgotListQuestion();
    }
}

