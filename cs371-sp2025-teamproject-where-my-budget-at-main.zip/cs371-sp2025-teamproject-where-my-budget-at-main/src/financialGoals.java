// Author: Jordan Henderson
// Helps with database


public class financialGoals {


    private boolean payDebt;
    private boolean bigPurchase;
    private boolean emergencyFund;
    private boolean futureInvesting;
    private boolean dailyExpenses;
    private boolean otherGoal;


    public financialGoals (boolean payDebt, boolean bigPurchase, boolean emergencyFund, boolean futureInvesting, boolean dailyExpenses, boolean otherGoal) {
        this.payDebt = payDebt;
        this.bigPurchase = bigPurchase;
        this.emergencyFund = emergencyFund;
        this.futureInvesting = futureInvesting;
        this.dailyExpenses = dailyExpenses;
        this.otherGoal = otherGoal;
    } // end FinancialGoal


    public boolean isPayDebt() {
        return payDebt;
    } // end isPayDebt
    public void setPayDebt(boolean payDebt) {
        this.payDebt = payDebt;
    } // end setPayDebt
    public boolean isBigPurchase() {
        return bigPurchase;
    } // end isBigPurchase
    public void setBigPurchase(boolean bigPurchase) {
        this.bigPurchase = bigPurchase;
    } // end setBigPurchase
    public boolean isEmergencyFund() {
        return emergencyFund;
    } // end isEmergencyFund
    public void setEmergencyFund(boolean emergencyFund) {
        this.emergencyFund = emergencyFund;
    } // end setEmergencyFund
    public boolean isFutureInvesting() {
        return futureInvesting;
    } // end isFutureInvesting
    public void setFutureInvesting(boolean futureInvesting) {
        this.futureInvesting = futureInvesting;
    } // end setFutureInvesting
    public boolean isDailyExpenses() {
        return dailyExpenses;
    } // end isDailyExpenses
    public void setDailyExpenses(boolean dailyExpenses) {
        this.dailyExpenses = dailyExpenses;
    } // end setDailyExpenses
    public boolean isOtherGoal() {
        return otherGoal;
    } // end isOtherGoal
    public void setOtherGoal(boolean otherGoal) {
        this.otherGoal = otherGoal;
    } // end setOtherGoal


} // end of class

