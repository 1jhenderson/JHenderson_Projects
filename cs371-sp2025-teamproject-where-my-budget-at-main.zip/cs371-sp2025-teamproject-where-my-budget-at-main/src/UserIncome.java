// Author: Angel Martinez


public class UserIncome {
    private String incomeType;
    private double incomeAmount;


    public UserIncome(String incomeType, double incomeAmount) {
        this.incomeType = incomeType;
        this.incomeAmount = incomeAmount;
    }


    public UserIncome() {
        this.incomeType = "Default";
        this.incomeAmount = 0.0;
    }
    public String getIncomeType() {
        return incomeType;
    }
    public void setIncomeType(String incomeType) {
        this.incomeType = incomeType;
    }
    public double getIncomeAmount() {
        return incomeAmount;
    }
    public void setIncomeAmount(double incomeAmount) {
        this.incomeAmount = incomeAmount;
    }
}



