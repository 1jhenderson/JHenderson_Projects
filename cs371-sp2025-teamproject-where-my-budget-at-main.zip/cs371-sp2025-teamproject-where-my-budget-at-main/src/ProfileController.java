import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;

public class ProfileController {

    // FXML injected fields
    @FXML
    private TextField nameField;
    
    @FXML
    private TextField emailField;
    
    @FXML
    private TextField phoneField;
    
    @FXML
    private Button saveButton;

    @FXML
    private Button backButton;
    
    @FXML
    private Pane profilePicturePane; // For the "Picture Here" area

    // Initialize method
    @FXML
    private void initialize() {
        // Set up event handlers
        saveButton.setOnAction(event -> handleSave());
        backButton.setOnAction(event -> handleBackButton());

        // You could add more initialization here
        // For example, load existing profile data
    }
    
    // Handle save button action
    private void handleSave() {
        String name = nameField.getText();
        String email = emailField.getText();
        String phone = phoneField.getText();
        
        // Validate inputs
        if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
            System.out.println("Please fill in all fields");
            return;
        }
        
        // Here you would typically save to a database or file
        System.out.println("Saving profile:");
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Phone: " + phone);
        
        // You could add confirmation message or navigation here
    }
    private void handleBackButton() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("homepage.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            // Handle error
        }
    }
    
    // Methods to set profile data (could be called from main app)
    public void setProfileData(String name, String email, String phone) {
        nameField.setText(name);
        emailField.setText(email);
        phoneField.setText(phone);
    }
    
    // Method to get current profile data
    public ProfileData getProfileData() {
        return new ProfileData(
            nameField.getText(),
            emailField.getText(),
            phoneField.getText()
        );
    }
    
    // Simple data holder class
    public static class ProfileData {
        private final String name;
        private final String email;
        private final String phone;
        
        public ProfileData(String name, String email, String phone) {
            this.name = name;
            this.email = email;
            this.phone = phone;
        }
        
        // Getters
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getPhone() { return phone; }

    }


}
