// Author: Angel Martinez and Jordan Henderson
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;


public class User {


    // Author: Angel Martinez
    private String username;
    private String password;
    private UserIncome userIncome;


    @JsonProperty("firstname")
    private String firstName;


    @JsonProperty("lastname")
    private String lastName;


    @JsonProperty("email")
    private String email;


// Author: Jordan Henderson
    private String securityQuestion;
    private String securityAnswer;
    private List<financialGoals> financialGoals;
    private IncomeInfo incomeInfo;
    private List<UserIncome> housingExpenses;
    private List<UserIncome> foodExpenses;
    private List<UserIncome> otherExpenses;


    public User() {
        // Default constructor required for Jackson
    }


    public User(String username, String password, UserIncome userIncome, String firstName, String lastName, String email, String securityQuestion, String securityAnswer) {
        this.username = username;
        this.password = password;
        this.userIncome = userIncome;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.securityQuestion = securityQuestion;
        this.securityAnswer = securityAnswer;
    }


    // Author: Angel Martinez
    public String getUsername(){
        return username;
    }
    // Author: Jordan Henderson
    public void setUsername(String username) {
        this.username = username;
    } // end setUsername
    // Author: Angel Martinez
    public String getPassword(){
        return password;
    }
    // Author: Jordan Henderson
    public void setPassword(String password) {
        this.password = password;
    } // end setPassword
    // Author: Angel Martinez
    public String getFirstname(){
        return firstName;
    }
    // Author: Jordan Henderson
    public void setFirstname(String firstname) {
        this.firstName = firstname;
    } // end setFirstname
    public String getLastname(){
        return lastName;
    }
    // Author: Jordan Henderson
    public void setLastname(String lastname) {
        this.lastName = lastname;
    } // end setLastname
    // AUthor: Angel Martinez
    public String getEmail(){
        return email;
    }
    // Author: Angel Martinez
    public void setEmail(String email) {
        this.email = email;
    } // end setEmail
    // Author: Jordan Henderson
    public String getSecurityQuestion() {
        return securityQuestion;
    } // end getSecurityQuestion
    // Author: Jordan Henderson
    public void setSecurityQuestion(String securityQuestion) {
        this.securityQuestion = securityQuestion;
    } // end setSecurityQuestion
    // Author: Jordan Henderson
    public String getSecurityAnswer() {
        return securityAnswer;
    } // end getSecurityAnswer
    // Author: Jordan Henderson
    public void setSecurityAnswer(String securityAnswer) {
        this.securityAnswer = securityAnswer;
    } // end setSecurityAnswer
    // Author: Angel Martinez
    public void setIncomeInfo(IncomeInfo incomeInfo) {
        this.incomeInfo = incomeInfo;
    } // end setIncomeInfo
    // Author: Angel Martinez
    public IncomeInfo getIncomeInfo() {
        return incomeInfo;
    } // end getIncomeInfo


   
}











