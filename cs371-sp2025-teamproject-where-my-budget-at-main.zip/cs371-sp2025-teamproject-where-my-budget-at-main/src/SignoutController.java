import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class SignoutController implements Initializable {

    @FXML
    private Label goodbyeLabel;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Set up a 3-second delay before redirecting
        PauseTransition delay = new PauseTransition(Duration.seconds(3));
        delay.setOnFinished(event -> redirectToLogin());
        delay.play();
    }

    private void redirectToLogin() {
        try {
            // Get the current stage from any node
            Stage stage = (Stage) goodbyeLabel.getScene().getWindow();
            
            // Load the login screen
            Parent root = FXMLLoader.load(getClass().getResource("WelcomeDocument.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Handle error appropriately
        }
    }

    // Optional: Method to personalize the goodbye message
    public void setUsername(String username) {
        goodbyeLabel.setText("Goodbye, " + username + "!");
    }
}