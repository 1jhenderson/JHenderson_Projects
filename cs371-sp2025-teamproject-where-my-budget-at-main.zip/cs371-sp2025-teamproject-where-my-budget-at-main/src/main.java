import java.awt.SystemTray;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.net.URL;
import java.io.IOException;


/* Authors: Jordan Henderson, Angel Martinez, Leon Nguyen
 * We originally had 3 different mains, Jordan combined them.
 */




public class Main extends Application {


    public enum scenes { // enum lets us have the different scenes that we can launch
        /* The first line lets us open the sign in/sign up scenes
         * The second line lets us open the homepage scene
         * The third line lets us open the pages for after a user signs up
         */
        WELCOME("WelcomeDocument.fxml", "Welcome"),
        HOMEPAGE("homepage.fxml", "Welcome, User"),
        INCOME("userincome.fxml", "Userincome");




        private final String fxmlFile;
        private final String title;


        scenes(String fxmlFile, String title) {
            this.fxmlFile = fxmlFile;
            this.title = title;
        } // end of private strings method


        public String getFxmlFile() {
            return fxmlFile;
        } // end of getter for fxmlFile


        public String getTitle() {
            return title;
        } // end of getter for title
    } // end of scenes


    @Override
    public void start(Stage primaryStage) throws Exception {
        launchScene(primaryStage, scenes.WELCOME); // this will always launch the sign in/ sign up pages first
    } // end of start


    // This method will let us launch any page so that we don't constantly have to start from the welcome pages when testing
    public static void launchScene(Stage stage, scenes sceneType) {
        try {
            URL fxmlLocation = Main.class.getResource("/WelcomeDocument.fxml");
            if (fxmlLocation == null) {
                System.err.println("FXML file not found: " + sceneType.getFxmlFile());
                return;
            }
            System.out.println("File found: " + fxmlLocation);


            FXMLLoader loader = new FXMLLoader(fxmlLocation);
            Parent root = loader.load();


            Scene scene;
            if (sceneType == scenes.HOMEPAGE) {
                scene = new Scene(root, 600, 400);
            } else {
                scene = new Scene(root);
            }
            stage.setTitle(sceneType.getTitle());
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    } // end of launchScene


    public static void switchToScene(Stage currentStage, scenes newScene) {
        try {
            currentStage.close();
            Stage newStage = new Stage();
            launchScene(newStage, newScene);
        } catch (Exception e) {
            e.printStackTrace();
        } // end of catch
    } // end of switchToScene


    public static void main(String[] args) {
        launch(args);
    } // end of mainFunc
} // end of main



