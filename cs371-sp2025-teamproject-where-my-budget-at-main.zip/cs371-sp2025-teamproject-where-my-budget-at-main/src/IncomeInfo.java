// Author: Jordan Henderson
 // will help provide the database with info


 public class IncomeInfo {
    private double incomeAmount;
    private String incomeFrequency;
    private double existingSavings;
    


    public IncomeInfo(double incomeAmount, String incomeFrequency, double existingSavings) {
        this.incomeAmount = incomeAmount;
        this.incomeFrequency = incomeFrequency;
        this.existingSavings = existingSavings;
    } // end IncomeInfo

    public double getDisposableIncome() {
        return incomeAmount - existingSavings;
    }
    public double getIncomeAmount() {
        return incomeAmount;
    } // end getIncomeAmount
    public void setIncomeAmount(double incomeAmount) {
        this.incomeAmount = incomeAmount;
    } // end setIncomeAmount
    public String getIncomeFrequency() {
        return incomeFrequency;
    } // end getIncomeFrequency
    public void setIncomeFrequency(String incomeFrequency) {
        this.incomeFrequency = incomeFrequency;
    } // end setIncomeFrequency
    public double getExistingSavings() {
        return existingSavings;
    } // end getExistingSavings
    public void setExistingSavings(double existingSavings) {
        this.existingSavings = existingSavings;
    } // end setExistingSavings
    public void setDisposableIncome(double disposableIncome) {
        this.incomeAmount = disposableIncome + existingSavings;
    } // end setDisposableIncome


} // end of class

