public class UserSavings{

    private String SavingsGoal;
    private double targetAmount;
    private double currentAmount;
    private double disposableIncome;


    public UserSavings(String firstName, String lastName, UserIncome userIncome, String email, String username, String password,
                       String SavingsGoal, double targetAmount, double currentAmount, double disposableIncome, String securityQuestion, String securityAnswer) {
        this.SavingsGoal = SavingsGoal;
        this.targetAmount = targetAmount;
        this.currentAmount = currentAmount;
        this.disposableIncome = disposableIncome;
    }

    public UserSavings(String SavingsGoal, double targetAmount, double currentAmount) {
        this.SavingsGoal = SavingsGoal;
        this.targetAmount = targetAmount;
        this.currentAmount = currentAmount;
    }
   
    public String getSavingsGoal() {
        return SavingsGoal;
    }
    public double getTargetAmount() {
        return targetAmount;
    }
    public double getCurrentAmount() {
        return currentAmount;
    }

    
}



