//Author: Angel Martinez
//Controller for the Resources page

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import java.io.IOException;

public class ResourcesController {

    @FXML
    private AnchorPane mainView;

    @FXML
    private AnchorPane financialPlanningView;

    @FXML
    private AnchorPane budgetingView;

    @FXML
    private AnchorPane retirementView;

    @FXML
    private AnchorPane socialSecurityView;

    @FXML
    private AnchorPane creditView;

    @FXML
    private AnchorPane sourcesView;

    @FXML
    private void showMainView() {
        hideAllViews();
        mainView.setVisible(true);
    }

    @FXML
    private void showFinancialPlanningView() {
        hideAllViews();
        financialPlanningView.setVisible(true);
        
    }

    @FXML
    private void showBudgetingView() {
        hideAllViews();
        budgetingView.setVisible(true);
    }

    @FXML
    private void showRetirementView() {
        hideAllViews();
        retirementView.setVisible(true);
    }

    @FXML
    private void showSocialSecurityView() {
        hideAllViews();
        socialSecurityView.setVisible(true);
    }

    @FXML
    private void showCreditView() {
        hideAllViews();
        creditView.setVisible(true);
    }

    @FXML
    private void showSourcesView() {
        hideAllViews();
        sourcesView.setVisible(true);
    }

    private void hideAllViews() {
        mainView.setVisible(false);
        financialPlanningView.setVisible(false);
        budgetingView.setVisible(false);
        retirementView.setVisible(false);
        socialSecurityView.setVisible(false);
        creditView.setVisible(false);
        sourcesView.setVisible(false);
    }

    @FXML
    private void handleHomeClick() {
        try {
            // Navigate back to the homepage
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/homepage.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) mainView.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Homepage");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load the Homepage.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
