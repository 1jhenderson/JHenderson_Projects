import java.awt.*;
import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.ComboBox;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.TableView;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.scene.Scene;


// Authors: Angel Martinez, Jordan Henderson, and Elizabeth Torres

public class UserIncomeController {


    @FXML
    private AnchorPane existingSavings;


    @FXML
    private TextField existingSavings_amt;


    @FXML
    private Button existingSavings_back;


    @FXML
    private Button existingSavings_continue;


    @FXML
    private CheckBox existingSavings_no;


    @FXML
    private CheckBox existingSavings_yes;


    @FXML
    private Hyperlink foodExpense_addItem;


    @FXML
    private Button foodExpense_back;


    @FXML
    private Button foodExpense_continue;


    @FXML
    private TextField foodExpense_groceries;


    @FXML
    private TextField foodExpense_restaurants;


    @FXML
    private AnchorPane foodExpenses;


    @FXML
    private CheckBox goals_bigPurchase;


    @FXML
    private CheckBox goals_checkOther;


    @FXML
    private CheckBox goals_dailyExpenses;


    @FXML
    private CheckBox goals_emergencyFund;


    @FXML
    private CheckBox goals_futureInvesting;


    @FXML
    private CheckBox goals_payDebt;


    @FXML
    private TextField goals_specifyOther;


    @FXML
    private Hyperlink housingExpense_addItem;


    @FXML
    private Button housingExpense_back;


    @FXML
    private TextField housingExpense_cable;


    @FXML
    private Button housingExpense_continue;


    @FXML
    private TextField housingExpense_electricity;


    @FXML
    private TextField housingExpense_naturalGas;


    @FXML
    private TextField housingExpense_rent;


    @FXML
    private TextField housingExpense_trash;


    @FXML
    private TextField housingExpense_water;


    @FXML
    private AnchorPane housingExpenses;


    @FXML
    private Button income_continue;


    @FXML
    private ComboBox<String> income_incomeFrequency;


    @FXML
    private TextField otehrExpense_Pets;


    @FXML
    private Hyperlink otherExpense_addItem;


    @FXML
    private Button otherExpense_back;


    @FXML
    private Button otherExpense_continue;


    @FXML
    private TextField otherExpense_entertainment;


    @FXML
    private TextField otherExpense_gas;


    @FXML
    private AnchorPane otherExpenses;


    @FXML
    private AnchorPane primaryFinancialGoals;


    @FXML
    private TextField userIncome;


    @FXML
    private AnchorPane userIncomePage;


    @FXML
    private Button userIncome_back;


    @FXML
    private TableView<?> userIncome_table;


    @FXML
    private Button primaryFinancialGoals_continue;


// Author: Jordan Henderson
    private User currentUser;
    public void setCurrentUser(User user) {
        this.currentUser = user;
    } // end of setCurrentUser


    /* Below function just sets which page is visible when the userincome.fxml is called.
     * Author: Jordan Henderson
     */
    @FXML
    public void initialize() {


        primaryFinancialGoals.setVisible(true);
        userIncomePage.setVisible(false);
        existingSavings.setVisible(false);
        housingExpenses.setVisible(false);
        foodExpenses.setVisible(false);
        otherExpenses.setVisible(false);


        setupEventHandlers();


 /* Author: Elizabeth Torres */
        income_incomeFrequency.getItems().addAll("Weekly", "Bi-Weekly", "SemiMonthly", "Monthly", "Quarterly", "Annually");
        income_incomeFrequency.setPromptText("Select Frequency: ");
        income_incomeFrequency.setOnAction(event -> {
            String selectedFrequency = income_incomeFrequency.getValue();
            System.out.println("Income frequency selected: " + selectedFrequency);
        });
    } // end of initialize


    public String getSelectedIncomeFrequency() {
        return income_incomeFrequency.getValue();
    }



/* Below function calls a function that connects the userincome sign up pages to the home page
 * Author: Jordan Henderson
 */
@FXML
private void handleContinue(ActionEvent event) {
    try {
        currentUser.setIncomeInfo(new IncomeInfo (
            Double.parseDouble(userIncome.getText()), income_incomeFrequency.getValue(), existingSavings_yes.isSelected() ? Double.parseDouble(existingSavings_amt.getText()) : 0.0));
       
            JsondataStorage.saveUser(currentUser);
            loadHomepage();
            showAlert("Success", "User income information saved successfully.");
    } catch (Exception e) {
        e.printStackTrace();
        showAlert("Error", "An error occurred while processing your request.");
    } // end of catch
}

/* Below function sets up what all of the buttons on the UI do: Authors per button */
private void setupEventHandlers() {
        // Primary financial goals page.
        //Author: Jordan Henderson
        goals_checkOther.setOnAction(event -> {
            goals_specifyOther.setDisable(!goals_checkOther.isSelected());
        }); // end of primary financial goals page set on action


/* Sets the continue button to continue to the next page.
Author: Jordan Henderson */
        primaryFinancialGoals_continue.setOnAction(event -> {
            primaryFinancialGoals.setVisible(false);
            userIncomePage.setVisible(true);
        });


        // User Income Page
        // Sets the user income page continue button to continue to the next page.
        // Author: Angel Martinez
        income_continue.setOnAction(event -> {
            String income = userIncome.getText();
           // if (income.isEmpty() || !income.matches("\\d+(\\.\\d{2})?")) {
           //     showAlert("Invalid Input", "Enter a valid income amount");
            //    return;
         //   } // end of if statement
            userIncomePage.setVisible(false);
            existingSavings.setVisible(true);
        }); // end of user income page set on action


        /* Sets the continue button for the existing savings page.
         * Author: Jordan Henderson
         */
        existingSavings_continue.setOnAction(event-> {
            existingSavings.setVisible(false);
            housingExpenses.setVisible(true);
        });


        /* Sets the back button to go back to the income entry page
         * Author: Jordan Henderson
         */
        existingSavings_back.setOnAction(event -> {
            existingSavings.setVisible(false);
            userIncomePage.setVisible(true);
        });

        // housing expenses page
        /* Sets the continue button to continue to the food expense page
         * Author: Jordan Henderson
         */
        housingExpense_continue.setOnAction(event -> {
            housingExpenses.setVisible(false);
            foodExpenses.setVisible(true);
        });

        /* Sets the back button on housing expenses to go to the previous page
         * Author: Jordan Henderson
         */
        housingExpense_back.setOnAction(event -> {
            housingExpenses.setVisible(false);
            existingSavings.setVisible(true);
        });


        /* Sets the continue button for the food expense page to go to the other expense page
         * Author: Jordan Henderson
         */
        foodExpense_continue.setOnAction(event->{
            foodExpenses.setVisible(false);
            otherExpenses.setVisible(true);
        });


        /* Sets the back button so it will go from the food expense page to the housing expense page
         * Author: Jordan Henderson
         */
        foodExpense_back.setOnAction(event -> {
            foodExpenses.setVisible(false);
            housingExpenses.setVisible(true);
        });

        // other expenses page
        /* Sets the continue button for the other expense page to go to the home page
         * Author: Jordan Henderson
         */
        otherExpense_continue.setOnAction(event -> {
            showAlert("Yay!", "Budget setup complete!");
            loadHomepage();
        });

/* Sets the back button for the other expense page to go to the food expense page
 * Author: Jordan Henderson
 */
        otherExpense_back.setOnAction(event -> {
            otherExpenses.setVisible(false);
            foodExpenses.setVisible(true);
        });
    } // end of setupEventHandlers

/* Function gets the showAlert so that we can call it when we want to show alerts (good or bad)
 * on our pages
 * Author: Jordan Henderson
 */
    private void showAlert(String title, String message) {
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
    } // end of showAlert


/* Function for switching to the home page. Called in above code
 * Author: Jordan Henderson
 */
    private void loadHomepage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("homepage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) otherExpense_continue.getScene().getWindow();


            stage.setScene(new Scene(root));
            stage.setTitle("Homepage");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            new alertMessage().errorMessage("Error loading homepage: " + e.getMessage());
        } // end of catch
    } // end of loadHomepage


    //Author: Angel Martinez
    // Function to calculate monthly income based on frequency and amount
    public double calculateMonthlyIncome() {
    String incomeFrequency = income_incomeFrequency.getValue();
    double incomeAmount = Double.parseDouble(userIncome.getText());
    double monthlyIncome = 0.0;

    switch (incomeFrequency) {
        case "Weekly":
            monthlyIncome = (incomeAmount * 52) / 12;
            break;
        case "Bi-Weekly":
            monthlyIncome = (incomeAmount * 26) / 12;
            break;
        case "SemiMonthly":
            monthlyIncome = incomeAmount * 2;
            break;
        case "Monthly":
            monthlyIncome = incomeAmount;
            break;
        case "Quarterly":
            monthlyIncome = incomeAmount / 3;
            break;
        case "Annually":
            monthlyIncome = incomeAmount / 12;
            break;
        default:
            showAlert("Error", "Please select a valid income frequency.");
    }

    return monthlyIncome;
}
//Author: Angel Martinez
//Function to calculate monthly expenses based on user input
public double calculateMonthlyExpenses() {
    double totalHousing = Double.parseDouble(housingExpense_rent.getText()) +
            Double.parseDouble(housingExpense_electricity.getText()) +
            Double.parseDouble(housingExpense_water.getText()) +
            Double.parseDouble(housingExpense_naturalGas.getText()) +
            Double.parseDouble(housingExpense_cable.getText()) +
            Double.parseDouble(housingExpense_trash.getText());

    double totalFood = Double.parseDouble(foodExpense_groceries.getText()) +
            Double.parseDouble(foodExpense_restaurants.getText());

    double totalOther = Double.parseDouble(otherExpense_entertainment.getText()) +
            Double.parseDouble(otherExpense_gas.getText()) +
            Double.parseDouble(otehrExpense_Pets.getText());

    return totalHousing + totalFood + totalOther;
}
//Author: Angel Martinez
//Function to calculate disposable income
    public double calculateDisposableIncome() {
    return calculateMonthlyIncome() - calculateMonthlyExpenses();
    }
}







