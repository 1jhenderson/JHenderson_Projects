/*import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Control;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;

public class darkModeManager {

    private static darkModeManager instance;
    private boolean darkModeEnabled = false;

    private final String darkBackground = "#4CAF50";
    private final String darkText = "#e0e0e0";
    private final String darkControl = "#444444";

    private final String lightBackground = "4CAF50";
    private final String lightText = "#333333";
    private final String lightControl = "#E0E0E0";

    private darkModeManager() {}

    public static darkModeManager getInstance() {
        if (instance == null) {
            instance = new darkModeManager();
        }
        return instance;
    }

    public boolean isDarkModeEnabled() {
        return darkModeEnabled;
    }

    public void setDarkModeEnabled(boolean enabled) {
        this.darkModeEnabled = enabled;
    }

    public void applyDarkMode(Scene scene) {
        if (scene == null) {
            return;
        }

        if (darkModeEnabled) {
            scene.getRoot().setStyle("-fx-background-color: " + darkBackground + ";");
            applyDarkStyles(scene.getRoot());

            scene.setFill(Color.web(darkBackground));
        }
        else {
            scene.getRoot().setStyle("-fx-background-color: " + lightBackground + ";");
            applyLightStyles(scene.getRoot());

            scene.setFill(Color.web(lightBackground));
        }

    }

    private void applyDarkStyles(Region parent) {
        parent.getChildrenUnmodifiable().forEach(child -> {
            if (child instanceof Control) {
                Control control = (Control) node;
                control.setStyle("-fx-background-color: " + darkControl + "; -fx-text-fill: " + darkText + ";");
            }
            else if (node instanceof Region) {
                Region region = (Region) node;
                region.setStyle("-fx-background-color: " + darkBackground + ";");
                applyDarkStyles(region);
            }
        });
    }

    private void applyLightStyles(Region parent) {
        parent.getChildrenUnmodifiable().forEach(child -> {
            if (child instanceof Control) {
                Control control = (Control) node;
                control.setStyle("-fx-background-color: " + lightControl + "; -fx-text-fill: " + lightText + ";");
            }
            else if (child instanceof Region) {
                Region region = (Region) node;
                region.setStyle("-fx-background-color: " + lightBackground + ";");
                applyLightStyles(region);
            }
        });
    }

    public void styleAlert(Alert alert) {
        if (darkModeEnabled) {
            alert.getDialogPane().setStyle("-fx-background-color: " + darkBackground + ";");
            alert.getDialogPane().getButtonTypes().forEach(buttonType -> {
                alert.getDialogPane().lookupButton(buttonType).setStyle("-fx-background-color: " + darkControl + "; -fx-text-fill: " + darkText + ";");
            });
        }
    }
}*/