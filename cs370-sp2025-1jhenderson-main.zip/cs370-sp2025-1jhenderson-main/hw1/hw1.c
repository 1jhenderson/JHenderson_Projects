/* 
Jordan Henderson

 1/23/2025

 Description: Program takes either 0 or 1 command line prompt that contains a text file
 and outputs the number of words in the file and the number of words that have more
 than six characters in them.

 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h> // to be able to use strlen (string length)


/*
processLine function takes each line in the text files and increases the word count count
and the count for the words that are longer than 6 letters. 

the strtok() function stores data between calls. It breaks the string into tokens.

\r is carriage return
*/
void processLine(char *line, int *wordCount, int *longWordCount) {

    char *token;

    token = strtok(line, " \t\n\r");

    while(token != NULL) {
        (*wordCount)++;

        if(strlen(token) >= 7) {
            (*longWordCount)++;
        } // end of if statement

        token = strtok(NULL, " \t\n\r");

    } // end of while loop

} // end of processLine function

/* 
argc stores the number of command line arguments including the
name of the program. argv is a pointer that lists all the arguments

main function calls the processLine function so that we can actually
use the processLine function. If more than one argument is given then 
it prints an error and usage message. If the file can't be opened it 
prints an error and usage message.
*/
int main(int argc, char *argv[]) { 

    FILE *inputFile = stdin;                                              // default file is stdin (if zero command line arguments are there)
    int wordCount = 0;
    char line[1024];                                                      // Due to requirements, 1024 is the largest file size we can accept, including the newline
    int longWordCount = 0;


    if(argc > 2) {                                                        // if more than one command line argument is given: 
        printf("error: More than one argument was given\n");              // Print error message, there are too many command line arguments given
        printf("usage: hw1 no_command_line_argument input_file");         // Usage message, hw1 is the name of the program. input_stdin uses stdin for input and input_file is for the name of the input file to use
        return -1;
    } else if(argc == 2) {
        inputFile = fopen(argv[1], "r");                                  // Open the file to read

        if(inputFile == NULL) {
             fprintf(stderr, "error: Can't open file for reading\n");     // if the input file can't be read
             printf("usage: hw1 no_command_line_argument input_file");    // usage message
             return -1;
        } // end of if statement
    } // end of else statement
    
    while(fgets(line, sizeof(line), inputFile)) {
        processLine(line, &wordCount, &longWordCount);                    // Calls the processLine function
    } // end of while loop
    
    printf("%d\t%d\n", wordCount, longWordCount);                         // Prints the word count and the count of words longer than 6 letters

    if(inputFile != stdin) {
        fclose(inputFile);                                                // have to close the file we opened so nothing weird happens
    } // end of if statement

    return 0;

} // end of main