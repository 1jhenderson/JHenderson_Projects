1. The variable usage error checking and reporting can be tested with VariableUsage.j 
	- it checks arrays and gives an error for any repeated variables and checks the variable types

2. More relational operators (>= and <=)
	- can be tested with relationalOps.j because it goes through if statements and checks
	with relational operators

3. Using string variables
	- can be tested with string.j because it gives a string and outputs it

	
