#include "astree.h"

int main() {
    ASTNode* node = NULL;
    return 0;
}