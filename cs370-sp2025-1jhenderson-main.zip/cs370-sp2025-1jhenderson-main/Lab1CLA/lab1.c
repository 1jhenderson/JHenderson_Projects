// Jordan Henderson
// 1/23/25
// Reads in integers and alternately adds and subtracts them. 
// Prints an error if the number is not an integer. Prints 0
// if there are no command line arguments

#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
    int sum = 0;
    int total = 0;


    for(int i = 1; i < argc; ++i) {
        char *endptr;        // should tack the invalid part of the argument
        long num = strtol(argv[i], &endptr, 10); // converts the string to an integer. works better than atoi bc atoi does not give error for invalid input

    if(*endptr != '\0') {
        printf("Error: argument %d is not an integer\n", i);  // if the argument entered is not an integer
        return 1;
    } // end of if statement

    if (i % 2 == 1) {

    total = total + num;   // if argument number is odd, add

} else {
    total = total - num;   // if argument number is even, subtract
}

    } // end of for loop

printf("The total is: %d\n", total); // print total answer

    return 0;

} // end of main
